﻿=== Aero Pantone 2016 Rose Quartz Serenity x48 Cursor Set ===

By: 4qts

Download: http://www.rw-designer.com/cursor-set/aero-pantone-2016-1

Author's description:

Aero 48x48 cursor set based on Pantone Color of the Year for 2016.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.